 <div class="footer">
 <div class="container">
                <b class="copyright">Designed & Developed By 

 - <a href="https://wamexs.com/" target="_blank">WEB & MARKETING EXPERTS LLC </a>.</b> All rights reserved.
            </div>
        </div>
        <script src="<?php echo base_url(); ?>assest-admin/scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assest-admin/scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assest-admin/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assest-admin/scripts/flot/jquery.flot.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assest-admin/scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assest-admin/scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assest-admin/scripts/common.js" type="text/javascript"></script>